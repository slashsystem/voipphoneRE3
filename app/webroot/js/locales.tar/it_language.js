var msg_lang = new Array();
msg_lang['Please input a value for the'] = "Inserire un valore per: ";
msg_lang['in key'] = "Sul tasto ";
msg_lang['Please select a value for input text value']="Selezionare un valore: ";
msg_lang['BLF Supports 9 digits (0-9) only for'] = "Per BLF sono validi solo numeri di 9 cifre del vostro range di numeri ";
msg_lang['maximum 10 digits for label'] = "Per l’etichetta di un tasto non sono consentiti più di 10 caratteri ";
msg_lang['digits only (0-9) between 1 and 30 digits for'] = "Il numero deve avere tra 1 e 30 caratteri ";
msg_lang['maximum 12 digits for Display'] = "Il nome visualizzato non può essere lungo più di 12 caratteri ";
msg_lang['Special charcters not allowed  for Display'] = "Il nome visualizzato non può contenere caratteri speciali ";
msg_lang['Password must have greater than 4 digits and less than 6 digits'] = "Per la password sono consentiti 4 - 6 numeri ";
msg_lang['uploading file'] = "Caricamento file in corso ";

jQuery(function($){
       $.timepicker.regional['fr'] = {
        timeOnlyTitle: 'FF',
        timeText: 'GG',
        hourText: 'HH',
        minuteText: 'LL',
        secondText: 'MM',
        millisecText: 'NN',
        timezoneText: 'OO',
        currentText: 'PP',
        closeText: 'QQ',
        amNames: ['AM', 'A'],
        pmNames: ['PM', 'P'],
        isRTL: false
};
	$.datepicker.regional['it'] = {
		closeText: 'Chiudi',
		prevText: '',
		nextText: '',
		currentText: 'Oggi',
		monthNames: ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno',
			'Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'],
		monthNamesShort: ['Gen','Feb','Mar','Apr','Mag','Giu',
			'Lug','Ago','Set','Ott','Nov','Dic'],
		dayNames: ['Domenica','Luned&#236','Marted&#236','Mercoled&#236','Gioved&#236','Venerd&#236','Sabato'],
		dayNamesShort: ['Dom','Lun','Mar','Mer','Gio','Ven','Sab'],
		dayNamesMin: ['Do','Lu','Ma','Me','Gi','Ve','Sa'],
		weekHeader: 'Sm',
		dateFormat: 'dd/mm/yy',
		firstDay: 1,
		isRTL: false,
		showMonthAfterYear: false,
		yearSuffix: ''};
	};
$.datepicker.setDefaults($.datepicker.regional['it']);
$.timepicker.setDefaults($.timepicker.regional['it']);
});
