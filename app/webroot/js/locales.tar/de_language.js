var msg_lang    =   new Array();
msg_lang['Please input a value for the'] 		=  "Bitte geben sie einen Wert ein für: ";
msg_lang['in key'] 					= "Auf der Taste ";
msg_lang['Please select a value for input text value'] 	= "Bitte slektieren Sie einen Wert: ";
msg_lang['BLF Supports 9 digits (0-9) only for'] 	= "Für BLF sind nur 9-stellige Nummern aus Ihrem Nummernbereich gültig ";
msg_lang['maximum 10 digits for label'] 		= "Für die Tastenbeschriftung sind nicht mehr als 10 Zeichen erlaubt ";
msg_lang['digits only (0-9) between 1 and 30 digits for']= "Die Nummer muss zwischen  1 und 30 Zeichen sein ";
msg_lang['maximum 12 digits for Display'] 		= "Der Anzeigenahmen darf nicht länger sein als 12 Zeichen ";
msg_lang['Special charcters not allowed  for Display'] 	= "Der Anzeigenahme erlaubt keine Sonderzeichen ";
msg_lang['uploading file'] 				= "Datei wird hochgeladen ";
msg_lang['Password must have greater than 4 digits and less than 6 digits']     =   "für das Psswort sind 4 - 6 Nummern erlaubt ";

//datepicker and timepicker

jQuery(function($){
       $.timepicker.regional['de'] = {
        timeOnlyTitle: 'FF',
        timeText: 'GG',
        hourText: 'HH',
        minuteText: 'LL',
        secondText: 'MM',
        millisecText: 'NN',
        timezoneText: 'OO',
        currentText: 'PP',
        closeText: 'QQ',
        amNames: ['AM', 'A'],
        pmNames: ['PM', 'P'],
        isRTL: false
};
	$.datepicker.regional['de'] = {
		closeText: 'schließen',
		prevText: '',
		nextText: '',
		currentText: 'heute',
		monthNames: ['Januar','Februar','März','April','Mai','Juni',
		'Juli','August','September','Oktober','November','Dezember'],
		monthNamesShort: ['Jan','Feb','Mär','Apr','Mai','Jun',
		'Jul','Aug','Sep','Okt','Nov','Dez'],
		dayNames: ['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'],
		dayNamesShort: ['So','Mo','Di','Mi','Do','Fr','Sa'],
		dayNamesMin: ['So','Mo','Di','Mi','Do','Fr','Sa'],
		weekHeader: 'KW',
		dateFormat: 'dd.mm.yy',
		firstDay: 1,
		isRTL: false,
		showMonthAfterYear: false,
		yearSuffix: ''
	};
$.datepicker.setDefaults($.datepicker.regional['de']);
$.timepicker.setDefaults($.timepicker.regional['de']);
});
