var msg_lang    =   new Array();
msg_lang['Please input a value for the'] = "S'il vous plaît entrer une valeur pour le ";
msg_lang['in key']= " dans les principaux ";
msg_lang['Please select a value for input text value'] = " S'il vous plaît sélectionnez une valeur pour la valeur de saisie de texte  ";
msg_lang['BLF Supports 9 digits (0-9) only for']= " BLF soutient 9 chiffres (0-9) que pour   ";
msg_lang['maximum 10 digits for label'] =  " maximum de 10 chiffres pour le label ";
msg_lang['digits only (0-9) between 1 and 30 digits for']= " seulement des chiffres (0-9) entre 1 et 30 chiffres pour  ";
msg_lang['maximum 12 digits for Display'] = " maximum de 12 chiffres pour l'affichage  ";
msg_lang['Special charcters not allowed  for Display'] = " charcters pas permis spécial pour l'affichage   ";
msg_lang['Password must have greater than 4 digits and less than 6 digits'] = " Mot de passe doit avoir plus de 4 chiffres et à moins de 6 chiffres ";
msg_lang['uploading file'] = "Le fichier est téléchargé (upload) ";

//DATE TIME PICKER LOCALIZATION

jQuery(function($){
       $.timepicker.regional['fr'] = {
        	timeOnlyTitle: 'FF',
        	timeText: 'GG',
        	hourText: 'HH',
        	minuteText: 'LL',
        	secondText: 'MM',
        	millisecText: 'NN',
        	timezoneText: 'OO',
        	currentText: 'PP',
        	closeText: 'QQ',
        	amNames: ['AM', 'A'],
        	pmNames: ['PM', 'P'],
        	isRTL: false
};
	$.datepicker.regional['fr'] =  {
		closeText: 'Fermer',
		prevText: '',
		nextText: '',
		currentText:  UTF8.decode('Aujourd\'hui'),
		monthNames:  ['Janvier',UTF8.decode('Février'),'Mars','Avril','Mai','Juin',
		UTF8.decode('Juillet'),UTF8.decode('Août'),'Septembre','Octobre','Novembre',UTF8.decode('Décembre')],
		monthNamesShort:  ['Janv.', UTF8.decode('Févr.'),'Mars','Avril','Mai','Juin',
		'Juil.', UTF8.decode('Août'),'Sept.','Oct.','Nov.', UTF8.decode('Déc.')],
		dayNames: ['Dimanche','Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'],
		dayNamesShort: ['Dim.','Lun.','Mar.','Mer.','Jeu.','Ven.','Sam.'],
		dayNamesMin: ['D','L','M','M','J','V','S'],
		weekHeader: 'Sem.',
		dateFormat: 'dd/mm/yy',
		firstDay: 1,
		isRTL: false,
		showMonthAfterYear: false,
		yearSuffix: ''
	};
$.datepicker.setDefaults($.datepicker.regional['fr']);
$.timepicker.setDefaults($.timepicker.regional['fr']);
});

